from flask import *
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/naturals'
app.config['SECRET_KEY'] = "random string"

db = SQLAlchemy(app)

@app.route("/")
def login():
	return render_template("login.html")
	
@app.route("/reg")
def register():
	return render_template("reg.html")

@app.route("/location_details")
def location_details():
	return render_template("location_details.html")

@app.route("/schemes")
def schemes():
	return render_template("schemes.html")
	
@app.route("/schems_allocation")
def schems():
	return render_template("schems_allocation.html")	
		
		
class register(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	first_name=db.Column(db.String)
	last_name=db.Column(db.String)
	email=db.Column(db.String)
	password=db.Column(db.String)
	password_confirmation=db.Column(db.String)
	
	def __init__(self,first_name,last_name,email,password,password_confirmation):
		self.first_name=first_name
		self.last_name=last_name
		self.email=email
		self.password=password
		self.password_confirmation=password_confirmation
		
	@app.route("/register_db",methods=["GET","POST"])
	def register_db():
		if request.method == 'POST':
			if not request.form['first_name'] or not request.form['last_name'] or not request.form['email'] or not request.form['password'] or not request.form['password_confirmation']:
				flash("Error")
			else:
				student=register(request.form['first_name'],request.form['last_name'],request.form['email'],request.form['password'],request.form['password_confirmation'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('register'))
		return render_template("reg.html")



class location_details(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	village=db.Column(db.String)
	city=db.Column(db.String)
	state=db.Column(db.String)
	country=db.Column(db.String)
	pincode=db.Column(db.String)
	
	def __init__(self,village,city,state,country,pincode):
		self.village=village
		self.city=city
		self.state=state
		self.country=country
		self.pincode=pincode
		
	@app.route("/location_details_db",methods=["GET","POST"])
	def location_details_db():
		if request.method == 'POST':
			if not request.form['village'] or not request.form['city'] or not request.form['state'] or not request.form['country'] or not request.form['pincode']:
				flash("Error")
			else:
				student=register(request.form['village'],request.form['city'],request.form['state'],request.form['country'],request.form['pincode'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('location_details'))
		return render_template("location_details.html")

if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
	
	
	
	
	
	
	
	




